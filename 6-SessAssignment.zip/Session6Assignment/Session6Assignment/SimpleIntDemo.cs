﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    /// <summary>
    /// find Simple interest by using Function
    /// </summary>
    class SimpleIntDemo
    {
        static void Main()
        {
            Console.WriteLine("*********Simple interest using Function********\n\n\n");
            SimpleIntDemo s1 = new SimpleIntDemo();
            Console.WriteLine("Enter amount");
           int amount=Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("enter time period in years");
            int time = Convert.ToInt32(Console.ReadLine());

           Console.WriteLine( s1.Simple(amount, time));
            Console.ReadLine();


        }
        public string Simple(int amount, int time)
        {
            int rate = 12;
            double SI = (amount * time * rate) / 100;
            return $"Simple interest on entered amount is {SI} by rate of interest {12}%";

        }

    }

   
}
