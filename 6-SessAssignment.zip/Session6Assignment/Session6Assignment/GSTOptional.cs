﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{/// <summary>
/// Calculate GST using optional parameter
/// </summary>
    class GSTOptional
    {
        static void Main()
        {
            Console.WriteLine("*******Program of CAlculating GST by using Optional parameter***********\n\n");
            GSTOptional g1 = new GSTOptional();
            Console.WriteLine("Enter amount for GST calculation");
            int amount=  Convert.ToInt32( Console.ReadLine());
            Console.WriteLine( g1.GST(amount));
            Console.ReadLine();
        }

        public string GST(int amount, int gst = 1)
        {
            int temp= (amount * gst / 100);
            amount = temp + amount;
            return $" GST amount {temp} and total amount {amount} ";
        }
    }

}
