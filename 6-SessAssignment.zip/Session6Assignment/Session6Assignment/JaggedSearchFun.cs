﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class JaggedSearchFun
    {
        /// <summary>
        /// Search elements in Jagged array by using Function
        /// </summary>
        static void Main()
        {
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 1, 2 };

            JaggedSearchFun j1 = new JaggedSearchFun();
            Console.WriteLine("enter num to search");
            int num = Convert.ToInt32(Console.ReadLine());
            j1.Jagged(nums, num);
            

        }

        //Function for searching Elements in Jagged array
        public void Jagged(int[][] nums,int num)
        {
            int count = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < nums[i].Length; j++)
                {

                    if (nums[i][j] == num)
                    {
                        Console.WriteLine("num found");
                    }
                    else
                    {
                        count++;

                    }


                }
            }
            if (count > 0)
            {
                Console.WriteLine("number not found");
                count = 0;
            }
            Console.ReadLine();

        }
    }
}
