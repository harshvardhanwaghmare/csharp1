﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    /// <summary>
    /// find factorial of given number
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("**********Find factorial of given number**** \n\n\n");
            Program p = new Program();
            Console.WriteLine("Enter number to find factorial");
           int num= Convert.ToInt32 (Console.ReadLine());
            p.Fact(num);
            Console.ReadLine();

        }

        public void Fact(int num)
        {
            int fact = 1;
            for (int i = 1; i <= num; i++)
            {
              fact   = fact * i;
            }
            Console.WriteLine("factorial of {0} number is {1}",num,fact);


        }
    }
}
