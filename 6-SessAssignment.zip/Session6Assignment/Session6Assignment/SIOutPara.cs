﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6Assignment
{
    class SIOutPara
    {
        static void Main()
        {
            Console.WriteLine("Program for calculating simple intrest using out parameter\n\n");
            SIOutPara s1 = new SIOutPara();

            Console.WriteLine("enter amount to calculate simple interest");
            int amount = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter time period");
            int time = Convert.ToInt32(Console.ReadLine());
            double temp;

           Console.WriteLine( s1.Simple(amount, time, out temp));
            
           
            Console.ReadLine();

        }

        public string Simple(int amount, int time,out double x)
        {
            int rate = 12;
            double SI = (amount * time * rate) / 100;
            double temp = (amount * time) + SI; 
            x = temp;
            return $"you entered amount is {amount} and simple Interest is {SI} and total amount {x}";

        }
    }
}
