﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class DollarRupee
    {
        /// <summary>
        /// Converting Dollar to Rupees and Rupees to dollar
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            double dollar = 10;
            int inRupee =(int)dollar * 71;
            Console.WriteLine("Dollar in rupees "+inRupee);

            int rupee = 700;
            double inDollar = rupee / 71;
            Console.WriteLine("Rupees into Dallar "+inDollar);

            Console.ReadLine();
         
        }
    }
}
