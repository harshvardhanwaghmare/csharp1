﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class TypeCasting1
    {
        /// <summary>
        /// Converting char to code and vice versa
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //Accepting input from user
            Console.WriteLine("enter character to convert into ascii");
            char c  =Convert.ToChar( Console.ReadLine());
           
            int ascii = (int)c;
            Console.WriteLine("ascii value for your char"+ascii);


            Console.WriteLine("enter ascii to convert into char");
            int a =Convert.ToInt32(Console.ReadLine());
            char d = (char)a;
            Console.WriteLine("char for your ascii"+d);
            Console.ReadLine();
        }
    }
}
