﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        //Program for Area of circle
        static void Main(string[] args)
        {
            const double PI = 3.14;
            int r = 10;
            double aoc = r * r * PI;
            Console.WriteLine("Area of circle {0} ",aoc);
            Console.ReadLine();
        }
    }
}
