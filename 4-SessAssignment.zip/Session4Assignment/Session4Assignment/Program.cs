﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    class Program
    {
        /// <summary>
        /// Number reverse from 50 to 0 using for loop
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {

            Console.WriteLine("Printing reverse numbers from 50 to 0\n\n");
            for (int i = 50; i >= 1; i--)
            {
                Console.Write(" {0} ",i);
            }
            Console.ReadLine();
        }
    }
}
