﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    /// <summary>
    /// Table printing by using for loop(input from user)
    /// </summary>
    class Table
    {
        static void Main()
        {
            Console.WriteLine("Table printing\n\n");
            Console.WriteLine("Enter number for table");
           int num=Convert.ToInt32( Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                int temp = num * i;//Main Logic
                Console.WriteLine(temp);
            }
            Console.ReadLine();
        }
    }
}
