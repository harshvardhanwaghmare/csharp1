﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4Assignment
{
    /// <summary>
    /// Odd numbers checking from given array by using FOR EACH 
    /// </summary>
    class OddByForEach
    {
        static void Main()
        {
            int[] array1 = {10,11,12,15,14,1,6,8,9,7,45,47,49,23,25,27,24,15 };

            //Array printing
            Console.WriteLine("Given Array");
            foreach (int v in array1)
            {
                
                    Console.Write(" {0}",v);
                
            }


            //Odd number Display
            Console.WriteLine("\n\nOdd numbers from given array");
            foreach (int v in array1)
            {
                if (v % 2 != 0)
                {
                    Console.WriteLine(v);
                }
               
            }
            Console.ReadLine();
        }
    }
}
