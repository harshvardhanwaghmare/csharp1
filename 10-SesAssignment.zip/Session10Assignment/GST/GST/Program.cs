﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GST
{
   public class GSTCal
    {
        double gst;
        double amount;

        public GSTCal(double GST, double amount)
        {
            this.gst = (GST/100);
            this.amount = amount;
        }

        public string CalGST()
        {
            
            double temp = amount * gst;
            amount = amount + temp;
            return $"GST amount is {temp} and Total amount is:{amount}";

        }
    }
}
