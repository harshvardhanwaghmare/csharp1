﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    public static class ExtensionMethod
    {
        public static void IsPositiveOrNeg(this int i, int value)
        {
            if (i > 0)
            {
                Console.WriteLine(i + value);
            }
            else
            {
                Console.WriteLine("given num is negative");
            }

        }

    }

    class TestExtensionMethod
    {
        
        static void Main()
        {
            Console.WriteLine("*********Checking number is positive or negative by using Extension method******\n\n");
            Console.WriteLine("Enter num check positive or negative");
            int num = Convert.ToInt32(Console.ReadLine());
            num.IsPositiveOrNeg(num);
            Console.ReadLine();
        }
    }
}
