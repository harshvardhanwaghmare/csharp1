﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignment
{
    /// <summary>
    /// Achieving abstraction by completing abstract methods in its derived class.
    /// </summary>
   abstract class ComputerDemo
    {
        public abstract string BootUp();
        public abstract string ShutDown();


    }

    class SuperComputer:ComputerDemo
    {
        public override string BootUp()
        {
            return "BootUp function is running from super computer class\n";
        }

        public override string ShutDown()
        {
            return "ShutDown is running from super computer class";
        }

    }

    class MainFrameComputer : ComputerDemo
    {
        public override string BootUp()
        {
            return "BootUp function is running from Main computer class\n";
        }

        public override string ShutDown()
        {
            return "ShutDown is running from Main computer class";
        }

    }

    class MicroComputer : ComputerDemo
    {
        public override string BootUp()
        {
            return "BootUp function is running from micro computer\n";
        }

        public override string ShutDown()
        {
            return "ShutDown is running from Micro computer\n";
        }

    }

    class MainComputer
    {
        static void Main()
        {
            Console.WriteLine("Achieving abstraction by completing abstract methods in its derived class.");
            MicroComputer m1 = new MicroComputer();
            MainFrameComputer m2 = new MainFrameComputer();
            SuperComputer s1 = new SuperComputer();

            Console.WriteLine(m2.BootUp());
            Console.WriteLine(m2.ShutDown());
            Console.WriteLine(s1.ShutDown());
            Console.WriteLine(s1.BootUp());
            Console.WriteLine( m1.BootUp());
            Console.WriteLine(m1.ShutDown());
            Console.ReadLine();
        }

    }
}
