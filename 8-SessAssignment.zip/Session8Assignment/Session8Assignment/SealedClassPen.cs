﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignment
{
    /// <summary>
    /// Program using sealed
    /// </summary>
   sealed class SealedClassPen
    {
        public string StartWriting()
        {
            return "Start writing is running";
        }

        public string StoptWriting()
        {
            return "Stop writing is running";
        }
    }

    class MainPen
    {
        static void Main()
        {
            Console.WriteLine("****Program using sealed****\n\n");
            SealedClassPen s1 = new SealedClassPen();
            Console.WriteLine( s1.StartWriting());
            Console.WriteLine( s1.StoptWriting());
            Console.ReadLine();
        }
    }
}
