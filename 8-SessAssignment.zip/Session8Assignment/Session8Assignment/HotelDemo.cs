﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignment
{
    /// <summary>
    /// Hotel requrments using Default constructor and parameterized constructor initilization and override ToString() method
    /// and using get and set properties
    /// </summary>
    class HotelDemo
    {
        static void Main()
        {
            Console.WriteLine("****HOTEL REQUIREMENT***\n\n\n");
            Room r1 = new Room();
           
            Console.WriteLine("Enter your number of persons:");
            int num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter your floor number:");
            int floor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter type (AC/non-AC):");
            string type = Console.ReadLine();

            Console.WriteLine("Enter capacity :");
            int capacity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Date YYYY/MM/DD :");
            DateTime date = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter price:");
            double price = Convert.ToDouble(Console.ReadLine());

            Room r2 = new Room(num,floor,type,capacity,date,price);
           Console.WriteLine( r2.ToString());
            
            Console.ReadLine();
        }

    }

    class Room
    {
        private int number;
        private int floor;
        private string type;
        private int capacity;
        private DateTime booked_time;
        private double price;

        //Optional
        public int Capacity { get; set; }
        public double Price { get; set; }


        public Room()
        {
            Console.WriteLine("Default constructor of Room class.");
            Console.WriteLine("\n\n");
        }

        public Room(int number, int floor, string type, int capacity, DateTime dateTime, double price)
        {
            this.number = number;
            this.floor = floor;
            this.type = type;
            this.capacity = capacity;
            this.booked_time = dateTime;
            this.price = price;
        }

        public override string ToString()
        {
            return string.Format(" Number= {0} \n Floor={1} \n type= {2} \n Capacity = {3} \n Booked_time = {4} \n price = {5}", number, floor, type, capacity, booked_time, price);
        }

    }

    
    
}
