﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignment
{

    class QnAForumDemo
    {
        private long Id;
        private string Name;
        private string email;
        private string DoB;

        //Optional
        public string eName { get; set; }
        public string Email { get; set; }


        public QnAForumDemo()
        {
            Console.WriteLine("Default constructor of QnAForum");
        }

        public QnAForumDemo(long Id, string Name, string email, string DoB)
        {
            this.Id = Id;
            this.Name = Name;
            this.email = email;
            this.DoB = DoB;
        }

        public override string ToString()
        {
            return string.Format("\n ID {0} \n Name {1} \n Email-Id {2} \n DateOfBirth {3}", Id, Name, email, DoB);
        }
        
    }

    class MainUser
    { 
        static void Main()
        {
            Console.WriteLine("Enter your Id number:");
            int id= Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("Enter your Name:");
            string name= Console.ReadLine();

            Console.WriteLine("Enter your E-mail Id:");
            string email= Console.ReadLine();

            Console.WriteLine("Enter your Date of birth:");
            string dob = Console.ReadLine();
            QnAForumDemo q1 = new QnAForumDemo();
            QnAForumDemo q2 = new QnAForumDemo(id,name,email,dob);
            Console.WriteLine( q2.ToString());
            Console.ReadLine();

        }
    }

    
}
