﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session8Assignment
{
    /// <summary>
    /// Achieving Inheritance by using one Interface and two derived classes and one main class.
    /// </summary>
   public interface BankDemo
    {
         void  Deposit( double amount);
         void Withdraw(double amount);
    }

    //Implimentaion Saving Class For deposit and withdraw
    class SavingAccount:BankDemo
    {
        double Balance = 50000;
        void BankDemo.Deposit( double amount)
        {
         
            Balance = Balance + amount;
            Console.WriteLine("Balance in saving account after depositing {0}",Balance);
        }

        void BankDemo.Withdraw(double amount)
        {
            
            if (Balance > amount)
            {
                Console.WriteLine("Balance in your Account {0}", Balance);
                Balance = Balance - amount;
                Console.WriteLine("Balance in saving account after withdrawing {0}", Balance);
            }
            else 
            {
                Console.WriteLine("Insufficient balance in your account");
            }
            
           
        }

    }


    //Implimentaion Current Class For deposit and withdraw
    class CurrentAccount :BankDemo
    {
        double Balance = 50000;
        void BankDemo.Deposit(double amount)
        {
           
            Console.WriteLine("Balance in your Account {0}", Balance);
            Balance = Balance + amount;
            Console.WriteLine("Balance in current account after depositing {0}", Balance);
        }

        void BankDemo.Withdraw(double amount)
        {
            
            if (Balance > amount)
            {
                Console.WriteLine("Balance in your Account {0}", Balance);
                Balance = Balance - amount;
                Console.WriteLine("Balance in current account after withdrawing {0}", Balance);
            }
            else
            {
                Console.WriteLine("Balance limit exceeds in your current account");
            }


        }

    }

    class MainBank 
    {
        static void Main()
        {
            Console.WriteLine("Enter your choice \n 1:Saving Account \n 2:Currentt Account");
            int ch= Convert.ToInt32( Console.ReadLine());
            BankDemo b1 = new SavingAccount();
            BankDemo b2 = new CurrentAccount();

            // 1st switch case for selection of Saving acc or Current Acc
            switch (ch)
            {
                //Saving Logic
                case 1:
                    Console.WriteLine("Welcome to saving account");
                    Console.WriteLine("select the operation \n1:Deposit \n2:Withdraw");
                    int ch1 = Convert.ToInt32(Console.ReadLine());

                    //2nd is for Deposit/Withdraw
                    switch (ch1)
                    {
                        case 1:
                            Console.WriteLine("Enter amount to deposit");
                            double amount = Convert.ToDouble(Console.ReadLine());
                            b1.Deposit(amount);
                            break;
                        case 2:
                            Console.WriteLine("Enter amount to Withdraw");
                            double amount1 = Convert.ToDouble(Console.ReadLine());
                            b1.Withdraw(amount1);
                            break;
                        default:Console.WriteLine("invalid entry");
                            break;
                    }
                    break;


                case 2:

                    //Current Logic
                    Console.WriteLine("Welcome to Current account");
                    Console.WriteLine("Select the operation \n1:Deposit \n2:Withdraw");
                    int ch2 = Convert.ToInt32(Console.ReadLine());

                    //2nd is for Deposit/Withdraw
                    switch (ch2)
                    {
                        case 1:
                            Console.WriteLine("Enter amount to deposit");
                            double amount = Convert.ToDouble(Console.ReadLine());
                            b2.Deposit(amount);
                            break;
                        case 2:
                            Console.WriteLine("Enter amount to Withdraw");
                            double amount1 = Convert.ToDouble(Console.ReadLine());
                            b2.Withdraw(amount1);
                            break;
                        default:
                            Console.WriteLine("invalid entry");
                            break;
                    }

                    break;
                    default:Console.WriteLine("invalid input");
                    break;
            }
            
            Console.ReadLine();
        }
    }
}
