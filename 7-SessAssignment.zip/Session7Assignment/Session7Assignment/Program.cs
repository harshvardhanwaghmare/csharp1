﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignment
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("****Student details initialization by using structure*******\n\n");
            Student s1 = new Student(101,"HARSH","Male",656565);
            Console.WriteLine( s1.Display());
            Console.ReadLine();

        }
    }

    struct Student
    {
        int RollNo;
        string name;
        string gender;
        long MobNo;

        public Student(int RollNo,string name, string gender, long MobNo)
        {
            this.RollNo = RollNo;
            this.name = name;
            this.gender = gender;
            this.MobNo = MobNo;
        }

        public string Display()
        {
            return string.Format("Roll number {0} \n student Name ={1}\n Gender= {2} \n mob num={3}",RollNo, name, gender, MobNo);
        }
    }
}
