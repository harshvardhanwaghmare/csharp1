﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7Assignment
{
    class EnumAss
    {
        static void Main()
        {
            Console.WriteLine("*******Displaying City NAME and CODE by using ENUM******\n\n");
            foreach (string name in Enum.GetNames(typeof(city)))
            {
                Console.WriteLine($"Name of city is:{ name}");
            }

            Console.WriteLine("\n\n");
            foreach (int code in Enum.GetValues(typeof(city)))
            {
                Console.WriteLine($"COde of city is {code}");
            }
            Console.ReadLine();
        }
    }

    enum city
    {
       pune=020,mumbai=100,nasik=101
    }

   
}
