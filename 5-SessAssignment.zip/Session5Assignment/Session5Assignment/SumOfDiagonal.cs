﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    class SumOfDiagonal
    {
        static void Main()
        {
            Console.WriteLine("********************Program for Sum of Diagonal elements in Array**********\n\n");
            int[,] array1 =new int[3, 3];
            Console.WriteLine("Enter array 9 elements");
             int sum = 0;

            //Insertion of array elements
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    array1[i,j] = Convert.ToInt32(Console.ReadLine());
                }

            }

            //Displaing arrayy elements
            Console.WriteLine("Entered array by user");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("\t{0}",array1[i,j]);
                }
                Console.WriteLine();

            }

            //Main logic for addition
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i == j)
                    {
                        sum = sum + array1[i, j];  //addition of diagonal elements
                        
                    }
                }

            }
            Console.WriteLine("Sum of diagonal elements of given array is :{0}",sum);
            Console.ReadLine();
        }
    }
}
