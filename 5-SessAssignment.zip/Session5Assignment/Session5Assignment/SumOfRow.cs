﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    /// <summary>
    /// Program for sum each row
    /// </summary>
    class SumOfRow
    {
        
        static void Main()
        {
            Console.WriteLine("Program for sum of rows in array\n\n\n");

            int[,] array1 = { { 10, 40, 50 }, { 60, 20, 70 },{ 80, 90, 30 } };

            Console.WriteLine("Given array");
            for (int i = 0; i <= 2; i++)
            {
                 for (int j = 0; j <= 2; j++)
                {

                    Console.Write(" {0}",array1[i,j]);
                }
                Console.WriteLine();


            }


            for (int i=0;i<=2;i++)
            {
                int sum = 0;
                for (int j = 0; j <=2; j++)
                {
                    
                    sum = sum + array1[i, j];
                }
                Console.WriteLine("\n\nsum of {0} row {1}",i, sum);


            }
           

            Console.ReadLine();
        }
    }
}
