﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    class ASCIIArray
    {
        /// <summary>
        /// ASCII conversion to charecter and charecter to ASCII value
        /// </summary>
        static void Main()
        {
            char[,] ch = { { 'a','b','c'},{'d', 'e','f'},{'g', 'h','i'} };
            int temp = 0;

            Console.WriteLine("\t ASCII to Code converter in 3x3 :\n\n");

            //For loop for accessing array elements
            for (int i = 0; i <= 2; i++)
            {
                
                for (int j = 0; j <=2 ; j++)
                {
                     temp =Convert.ToInt32( ch[i, j]);//ASCII to code conversion
                   
                    Console.Write(" \t {0}-{1}\t",ch[i,j],temp);

                }
                Console.WriteLine();
                
            }

            Console.ReadLine();
        }
    }
}
