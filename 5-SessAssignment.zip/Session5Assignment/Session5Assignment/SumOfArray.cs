﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    /// <summary>
    /// Sum of single dim Array.
    /// </summary>
    class SumOfArray
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program for addition of single dim array\n\n\n");
            int[] array1 = {10,20,30,40};
            int sum = 0;

            //Display array
            for (int i = 0; i <= 3; i++)
            {
                Console.Write(" {0} ",array1[i]);
            }


            for (int i = 0; i <= 3; i++)
            {
                int temp = array1[i];
                sum = sum + temp;
               
            }
            Console.WriteLine("\n\nsum of given array {0}",sum);

            Console.ReadLine();
        }
    }
}
