﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5Assignment
{
    class JaggedSearch
    {
        /// <summary>
        /// Search elemennt in given Jagged Array
        /// </summary>
        static void Main()
        {
            Console.WriteLine("Search elemennt in given Jagged Array\n\n");
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 1, 2 };
                       
            //For loop for printing array elements
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in nums[i])
                {
                    Console.Write(" {0}",temp);
                }
                Console.WriteLine();
            }


            Console.WriteLine("Enter number to search in given above aaray");
            int num = Convert.ToInt32(Console.ReadLine());

            int count = 0;
            for (int i = 0; i < 2; i++)
            {
                for(int j=0;j<nums[i].Length;j++)
                {

                    if (nums[i][j] == num)
                    {
                        count++;
                        
                        break;
                    }
                                      
                }
            }
            if (count == 1)
            {
                Console.WriteLine("num found in given array");
                   
            }
            else
            {
                Console.WriteLine("number not found in above array");
            }
            Console.ReadLine();
        }
    }
}
