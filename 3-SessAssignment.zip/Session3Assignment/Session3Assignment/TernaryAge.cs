﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    class TernaryAge
    {
        /// <summary>
        /// The person is major or minor by using Ternary operator
        /// </summary>
        static void Main()
        {
            Console.WriteLine("Enter your age");
            //Accepting input from user
            int age = Convert.ToInt32(Console.ReadLine());

            string result = age <18 ? "you are minor age" : "you are major age";
            Console.WriteLine("{0}",result);
            Console.ReadLine();
        }
    }
}
