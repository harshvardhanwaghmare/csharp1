﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    /// <summary>
    /// Checking person in major or minor by using IF Else
    /// </summary>
    class IfElseMajorMinor
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter age of person to check is it Major or minor ");
            int age=Convert.ToInt32(Console.ReadLine());
                        if (age < 18)
            {
                Console.WriteLine("The person is Minor");
            }
            else
            {
                Console.WriteLine("The person is major");
            }
            Console.ReadLine();
        }
    }
}
