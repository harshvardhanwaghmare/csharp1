﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    class IfElseIfElse
    {
        /// <summary>
        /// Checking grade of students by using percentage.(by using if else if else)
        /// </summary>
        static void Main()
        {
            //accepting input from user
            Console.WriteLine("Enter percentage of student");
            int per = Convert.ToInt32(Console.ReadLine());

            if (per >= 75)
            {
                Console.WriteLine("student got distinction");
            }
            else if (per >= 60 && per < 75)
            {
                Console.WriteLine("student got first class");
            }
            else if (per >= 40 && per < 60)
            {
                Console.WriteLine("student got second class");
            }
            else
            {
                Console.WriteLine("Failed");
            }
            Console.ReadLine();
        }
    }
}
