﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session3Assignment
{
    class DayDisplay
    {
        /// <summary>
        /// Number wise day 1. Monday 2.tue 3.wed 4.thurs 5.
        /// </summary>
        static void Main()
        {
            //accepting input from user
            Console.WriteLine("Enter number 1 to 7 display day\n");
            int num = Convert.ToInt32(Console.ReadLine());

            switch (num)
            {
                case 1:Console.WriteLine("MONDAY");
                    break;

                case 2:
                    Console.WriteLine("TUESDAY");
                    break;

                case 3:
                    Console.WriteLine("WENDSDAY");
                    break;

                case 4:
                    Console.WriteLine("THURSDAY");
                    break;

                case 5:
                    Console.WriteLine("FRIDAY");
                    break;

                case 6:
                    Console.WriteLine("SATURDAY");
                    break;

                case 7:
                    Console.WriteLine("SUNDAY");
                    break;

                default:
                    Console.WriteLine("invalid input");
                    break;


            }
            Console.ReadLine();
           
        }
        
    }
}
